from flask import Flask
from flask import request
from flask import make_response
from flask import abort
from flask import redirect
from flask import render_template


app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/Contact')
def contact():
    return render_template('Contact.html')

@app.route('/Competences')
def competences():
    return render_template('Competences.html')

@app.route('/Etudes')
def etudes():
    return render_template('Etudes.html')

@app.route('/Experiences')
def experiences():
    return render_template('Experiences.html')



@app.route('/skills/<skill>')
def skills(skill):
    return f"<h2> ceci est mon expérience avec {skill}</h2>"

@app.route('/administration')
def administration():
    abort(403)

@app.errorhandler(403)
def forbidden(e):
    return render_template('403.html'), 403

if __name__ == '__main__':
    app.run(debug=True)